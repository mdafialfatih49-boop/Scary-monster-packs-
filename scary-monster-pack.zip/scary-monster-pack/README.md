# Scary Monster Pack — Fabric 1.20.1

Mod Fabric bertema horor ringan untuk Minecraft Java 1.20.1. Proyek ini berisi empat mob kustom, model dan tekstur pixel-art, suara orisinal, spawn egg, loot table, serta tiga artefak utilitas non-damage.

## Isi mod

| Mob | Health | Damage | Keunikan |
|---|---:|---:|---|
| Gloom Stalker | 34 HP | 6 | Humanoid tinggi dengan lengan panjang dan jubah robek; jangkauan deteksi luas |
| Hollow Wraith | 26 HP | 4.5 | Efek Darkness pada pemain yang berada dekat dengannya secara berkala |
| Mire Brute | 58 HP | 9 | Besar, lambat, dan memiliki knockback resistance tinggi |
| Bone Crawler | 20 HP | 3.5 | Kecil, cepat, dan memiliki delapan kaki beranimasi |

Artefak utilitas: **Whisper Lantern** memberi Night Vision singkat, **Echo Bell** membuat monster sekitar menoleh ke pemakai, dan **Warding Charm** memberi Resistance serta Absorption sementara. Item-item ini tidak memberikan damage.

## Versi toolchain

- Minecraft Java: `1.20.1`
- Java: `17`
- Fabric Loader: `0.16.14`
- Fabric API: `0.92.12+1.20.1`
- Yarn mappings: `1.20.1+build.10`
- Fabric Loom: `1.6.12`
- Gradle: `8.8`

## Build otomatis di GitHub (tanpa Gradle lokal)

1. Buat repository GitHub baru, lalu unggah seluruh isi folder proyek ini ke branch `main`.
2. Buka tab **Actions**. Workflow **Build Fabric Mod** berjalan otomatis saat push, atau jalankan manual melalui **Run workflow**.
3. Buka hasil workflow yang selesai, lalu unduh artifact bernama `scary-monster-pack-<commit>`.
4. Di dalam artifact, gunakan `scary-monster-pack-1.0.0.jar` (bukan file `-sources.jar`).

Workflow menyiapkan Temurin Java 17 dan Gradle 8.8 di runner GitHub, membuat wrapper Gradle resmi, lalu menjalankan `./gradlew build`. File hasil build berada di `build/libs/`.

## Build dari komputer sendiri

Gunakan JDK 17 dan Gradle 8.8+. Jalankan:

```bash
gradle wrapper --gradle-version 8.8
./gradlew build
```

JAR hasil build ada di `build/libs/`.

## Instalasi

1. Pastikan instance Minecraft menggunakan **Java Edition 1.20.1** dengan Fabric Loader.
2. Pasang Fabric API `0.92.12+1.20.1` pada instance yang sama.
3. Salin `scary-monster-pack-1.0.0.jar` ke folder `mods` instance.
4. Jalankan game dan buka tab kreatif **Spawn Eggs** untuk menemukan empat telur monster. Artefak utilitas ada di tab **Tools**.

Launcher Android seperti Zalith atau MJLauncher hanya akan bekerja bila versi launcher, renderer, dan runtime Java yang digunakan kompatibel dengan instance Fabric 1.20.1. Dukungan tiap perangkat/launcher berbeda; workflow hanya membangun mod, bukan menguji kompatibilitas perangkat Android tertentu.

## Perintah tes

```mcfunction
/summon scarymonster:gloom_stalker
/summon scarymonster:hollow_wraith
/summon scarymonster:mire_brute
/summon scarymonster:bone_crawler
```

Mob dipanggil lewat spawn egg atau `/summon`; konfigurasi ini tidak menambahkan natural spawning ke biome vanilla.

## Regenerasi tekstur dan suara

Seluruh PNG dan OGG sudah disertakan pada `src/main/resources/assets/scarymonster/`. `generate_assets.py` adalah generator lokal untuk meregenerasi tekstur pixel-art dan efek suara sintetis yang digunakan proyek. Jalankan dengan Python 3, Pillow, NumPy, dan FFmpeg.

## Catatan proyek

Model monster dibuat langsung dengan `ModelPart`/`TexturedModelData` dari kode Java, jadi tidak membutuhkan GeckoLib atau library animasi tambahan. Animasi berjalan dengan sistem model Minecraft bawaan.

## Catatan kompatibilitas dan verifikasi

Workflow GitHub adalah jalur build yang disiapkan untuk proyek ini: runner memasang Java 17 dan Gradle 8.8, menghasilkan Gradle Wrapper resmi, lalu membangun mod. Arsip proyek menyertakan skrip pemanggil `gradlew` agar langkah build lokal konsisten setelah wrapper dibuat. Build belum dapat dieksekusi di lingkungan penyusunan ini karena distribusi Gradle tidak dapat diunduh dari jaringan; gunakan status workflow GitHub untuk verifikasi kompilasi final.

Paket menyertakan **15 efek suara OGG** orisinal (ambient, hurt, death untuk tiap mob serta tiga bunyi artefak). Model dibuat dari geometri `ModelPart` dan tekstur PNG 64×64 / 16×16 yang sudah disertakan.
