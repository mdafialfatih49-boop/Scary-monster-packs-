from PIL import Image, ImageDraw
import random, math, os, wave, struct, subprocess
import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
ASSET = os.path.join(ROOT, 'src/main/resources/assets/scarymonster')
os.makedirs(os.path.join(ASSET, 'textures/entity'), exist_ok=True)
os.makedirs(os.path.join(ASSET, 'textures/item'), exist_ok=True)
os.makedirs(os.path.join(ASSET, 'sounds'), exist_ok=True)

# Pixel-art texture atlases used by the custom Java entity models.
def make_monster_texture(name, base, shade, accent, highlight, seed, motif):
    random.seed(seed)
    im = Image.new('RGBA', (64, 64), base)
    px = im.load()
    for y in range(64):
        for x in range(64):
            n = random.random()
            if n < 0.18:
                px[x, y] = shade
            elif n < 0.23:
                px[x, y] = accent
            elif n < 0.26:
                px[x, y] = highlight
    d = ImageDraw.Draw(im)
    # Panel seams and small pixel highlights add a hand-painted block texture.
    for x in range(0, 64, 8):
        d.line((x, 0, x, 63), fill=(*shade[:3], 125), width=1)
    for y in range(0, 64, 8):
        d.line((0, y, 63, y), fill=(*shade[:3], 95), width=1)
    if motif == 'gloom':
        # Eyes, forehead rune, and ragged red stitch accents.
        for x in (6, 10):
            d.rectangle((x, 5, x+1, 6), fill=highlight)
        d.rectangle((7, 2, 8, 3), fill=accent)
        d.line((2, 26, 5, 30, 8, 27, 11, 31), fill=accent, width=1)
        for y in (42, 48, 54, 60):
            d.line((28, y, 31, y-2, 35, y), fill=accent, width=1)
        d.polygon([(46, 12),(48,8),(50,12),(52,8),(54,12)], fill=highlight)
    elif motif == 'wraith':
        d.rectangle((6, 4, 8, 5), fill=highlight)
        d.rectangle((12, 4, 14, 5), fill=highlight)
        d.line((3, 25, 8, 21, 11, 27, 15, 22), fill=accent, width=2)
        for x in (22, 30, 38, 46, 54):
            d.line((x, 35, x-2, 43, x+1, 50, x-1, 58), fill=highlight, width=1)
        d.ellipse((49, 2, 55, 8), outline=accent, width=1)
    elif motif == 'brute':
        d.rectangle((5, 5, 8, 7), fill=highlight)
        d.rectangle((12, 5, 15, 7), fill=highlight)
        d.polygon([(3, 20),(7, 14),(11, 20),(16, 14),(20, 20)], fill=accent)
        for x in (4, 12, 20, 28, 36, 44, 52, 60):
            d.rectangle((x, 36+(x%3), x+2, 39+(x%3)), fill=shade)
        d.line((24, 48, 29, 45, 35, 48, 40, 44), fill=highlight, width=2)
    else:
        # Pale segmented plates with dark gaps and bright eyes.
        d.rectangle((4, 21, 6, 22), fill=accent)
        d.rectangle((10, 21, 12, 22), fill=accent)
        for x in range(2, 63, 8):
            d.line((x, 28, x+3, 31, x+1, 35), fill=highlight, width=1)
        for y in range(42, 64, 5):
            d.line((30, y, 33, y+1, 36, y), fill=shade, width=1)
        d.polygon([(48, 12),(50, 7),(52, 12)], fill=highlight)
    im.save(os.path.join(ASSET, 'textures/entity', f'{name}.png'))

make_monster_texture('gloom_stalker', (34, 27, 47, 255), (15, 13, 25, 255), (126, 35, 60, 255), (232, 93, 100, 255), 101, 'gloom')
make_monster_texture('hollow_wraith', (35, 62, 77, 255), (13, 25, 40, 255), (67, 141, 164, 255), (174, 235, 232, 255), 202, 'wraith')
make_monster_texture('mire_brute', (86, 99, 46, 255), (39, 49, 28, 255), (121, 87, 48, 255), (183, 164, 82, 255), 303, 'brute')
make_monster_texture('bone_crawler', (191, 183, 156, 255), (74, 64, 57, 255), (43, 122, 119, 255), (238, 225, 195, 255), 404, 'crawler')

# Small, crisp item icons for 16x16 GUI inventory rendering.
def save_item(name, draw_fn):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    draw_fn(d)
    im.save(os.path.join(ASSET, 'textures/item', f'{name}.png'))

def lantern(d):
    d.rectangle((6, 1, 9, 2), fill=(165, 166, 159, 255))
    d.rectangle((5, 3, 10, 12), fill=(64, 50, 39, 255), outline=(22, 20, 24, 255))
    d.rectangle((7, 4, 8, 10), fill=(174, 232, 191, 255))
    d.rectangle((6, 5, 9, 9), fill=(110, 204, 160, 255))
    d.rectangle((4, 13, 11, 14), fill=(136, 93, 56, 255))
    d.point((8, 6), fill=(244, 255, 200, 255))
    d.line((6, 0, 9, 0), fill=(203, 181, 116, 255))

def bell(d):
    d.rectangle((7, 1, 8, 3), fill=(220, 194, 104, 255))
    d.rectangle((5, 4, 10, 5), fill=(221, 187, 84, 255))
    d.polygon([(5, 5),(10, 5),(12, 12),(3, 12)], fill=(191, 145, 57, 255), outline=(77, 55, 32, 255))
    d.rectangle((3, 12, 12, 13), fill=(236, 204, 112, 255))
    d.rectangle((7, 13, 8, 15), fill=(120, 83, 40, 255))
    d.point((6, 7), fill=(255, 229, 151, 255))

def charm(d):
    d.line((7, 1, 8, 1, 8, 3), fill=(191, 177, 211, 255))
    d.polygon([(8, 3),(13, 7),(8, 14),(3, 7)], fill=(78, 48, 109, 255), outline=(26, 17, 44, 255))
    d.polygon([(8, 4),(11, 7),(8, 11),(5, 7)], fill=(150, 100, 202, 255))
    d.rectangle((7, 6, 8, 9), fill=(220, 194, 245, 255))
    d.point((8, 7), fill=(255, 255, 255, 255))

save_item('whisper_lantern', lantern)
save_item('echo_bell', bell)
save_item('warding_charm', charm)

# Resource models for utility items and spawn eggs.
models = {
    'whisper_lantern': '{"parent":"minecraft:item/generated","textures":{"layer0":"scarymonster:item/whisper_lantern"}}',
    'echo_bell': '{"parent":"minecraft:item/generated","textures":{"layer0":"scarymonster:item/echo_bell"}}',
    'warding_charm': '{"parent":"minecraft:item/generated","textures":{"layer0":"scarymonster:item/warding_charm"}}',
}
for egg in ['gloom_stalker_spawn_egg', 'hollow_wraith_spawn_egg', 'mire_brute_spawn_egg', 'bone_crawler_spawn_egg']:
    models[egg] = '{"parent":"minecraft:item/template_spawn_egg"}'
for name, content in models.items():
    with open(os.path.join(ASSET, 'models/item', name + '.json'), 'w', encoding='utf-8') as f:
        f.write(content + '\n')

# Original synthesized, soft horror ambience/chime clips (no external samples).
SR = 22050

def envelope(n, fade=0.18):
    t = np.arange(n) / SR
    dur = n / SR
    attack = np.clip(t / max(0.01, fade * 0.5), 0, 1)
    release = np.clip((dur - t) / max(0.01, fade), 0, 1)
    return attack * release

def synth(name, duration, freqs, noise=0.0, tremolo=0.0, seed=0, waveform='sine'):
    rng = np.random.default_rng(seed)
    n = int(SR * duration)
    t = np.arange(n) / SR
    signal = np.zeros(n, dtype=np.float64)
    for i, f in enumerate(freqs):
        glide = f * (1.0 + 0.035 * np.sin(2 * np.pi * (0.18 + 0.07*i) * t))
        phase = 2*np.pi*np.cumsum(glide)/SR
        component = np.sin(phase)
        if waveform == 'softsquare':
            component = np.tanh(2.0 * component)
        signal += component / (i + 1)
    if noise:
        raw = rng.normal(0, 1, n)
        # Gentle low-pass smoothing keeps the texture soft and avoids harsh clicks.
        smooth = np.convolve(raw, np.ones(24)/24, mode='same')
        signal += smooth * noise
    if tremolo:
        signal *= (0.75 + 0.25*np.sin(2*np.pi*tremolo*t))
    signal *= envelope(n, min(0.28, duration/3))
    peak = max(0.001, np.max(np.abs(signal)))
    signal = signal / peak * 0.7
    pcm = np.int16(np.clip(signal, -1, 1) * 32767)
    wav = os.path.join(ASSET, 'sounds', name + '.wav')
    with wave.open(wav, 'wb') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR)
        wf.writeframes(pcm.tobytes())
    ogg = os.path.join(ASSET, 'sounds', name + '.ogg')
    subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', wav, '-c:a', 'libvorbis', '-q:a', '3', ogg], check=True)
    os.remove(wav)

clips = [
    ('gloom_ambient', 1.65, [62, 93, 124], 0.08, 0.25, 11, 'sine'),
    ('gloom_hurt', 0.48, [105, 158], 0.12, 0.0, 12, 'softsquare'),
    ('gloom_death', 0.85, [74, 55, 37], 0.16, 0.0, 13, 'softsquare'),
    ('wraith_ambient', 1.75, [196, 247, 311], 0.24, 0.32, 21, 'sine'),
    ('wraith_hurt', 0.5, [220, 165], 0.19, 0.0, 22, 'sine'),
    ('wraith_death', 0.95, [330, 220, 147], 0.22, 0.0, 23, 'sine'),
    ('brute_ambient', 1.45, [48, 61, 73], 0.1, 0.18, 31, 'softsquare'),
    ('brute_hurt', 0.55, [58, 82], 0.13, 0.0, 32, 'softsquare'),
    ('brute_death', 0.9, [49, 41, 31], 0.12, 0.0, 33, 'softsquare'),
    ('crawler_ambient', 1.2, [140, 188, 234], 0.18, 1.8, 41, 'sine'),
    ('crawler_hurt', 0.36, [180, 270], 0.1, 0.0, 42, 'softsquare'),
    ('crawler_death', 0.65, [162, 108, 81], 0.14, 0.0, 43, 'softsquare'),
    ('lantern_pulse', 0.8, [440, 660, 880], 0.015, 0.0, 51, 'sine'),
    ('echo_chime', 0.9, [392, 587, 784], 0.01, 0.0, 52, 'sine'),
    ('warding_chime', 0.85, [523, 659, 1047], 0.01, 0.0, 53, 'sine'),
]
for args in clips:
    synth(*args)
print('Generated textures, item models, and', len(clips), 'original OGG sound effects.')
