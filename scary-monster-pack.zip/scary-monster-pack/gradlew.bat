@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle tidak ditemukan. GitHub Actions memasang Gradle 8.8 sebelum build.
  exit /b 1
)
gradle -p "%~dp0" %*
