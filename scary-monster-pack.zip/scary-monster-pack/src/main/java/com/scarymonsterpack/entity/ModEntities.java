package com.scarymonsterpack.entity;

import com.scarymonsterpack.ScaryMonsterMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {
    public static final EntityType<GloomStalkerEntity> GLOOM_STALKER = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(ScaryMonsterMod.MOD_ID, "gloom_stalker"),
            EntityType.Builder.create(GloomStalkerEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.72f, 2.35f).maxTrackingRange(10).build("scarymonster:gloom_stalker")
    );

    public static final EntityType<HollowWraithEntity> HOLLOW_WRAITH = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(ScaryMonsterMod.MOD_ID, "hollow_wraith"),
            EntityType.Builder.create(HollowWraithEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(0.8f, 2.15f).maxTrackingRange(10).build("scarymonster:hollow_wraith")
    );

    public static final EntityType<MireBruteEntity> MIRE_BRUTE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(ScaryMonsterMod.MOD_ID, "mire_brute"),
            EntityType.Builder.create(MireBruteEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(1.25f, 2.2f).maxTrackingRange(10).build("scarymonster:mire_brute")
    );

    public static final EntityType<BoneCrawlerEntity> BONE_CRAWLER = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(ScaryMonsterMod.MOD_ID, "bone_crawler"),
            EntityType.Builder.create(BoneCrawlerEntity::new, SpawnGroup.MONSTER)
                    .setDimensions(1.25f, 0.9f).maxTrackingRange(10).build("scarymonster:bone_crawler")
    );

    private ModEntities() { }

    public static void register() {
        FabricDefaultAttributeRegistry.register(GLOOM_STALKER, GloomStalkerEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(HOLLOW_WRAITH, HollowWraithEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(MIRE_BRUTE, MireBruteEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(BONE_CRAWLER, BoneCrawlerEntity.createAttributes());
        ScaryMonsterMod.LOGGER.info("Registered four custom monsters");
    }
}
