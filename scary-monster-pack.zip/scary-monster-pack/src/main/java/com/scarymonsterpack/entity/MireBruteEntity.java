package com.scarymonsterpack.entity;

import com.scarymonsterpack.sound.ModSounds;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

public class MireBruteEntity extends AbstractScaryMonsterEntity {
    public MireBruteEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 58.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.18)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 9.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.75)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 28.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 0.92, true));
        this.goalSelector.add(7, new WanderAroundFarGoal(this, 0.55));
        this.goalSelector.add(8, new LookAtEntityGoal(this, PlayerEntity.class, 10.0f));
        this.goalSelector.add(9, new LookAroundGoal(this));
        this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override protected SoundEvent getAmbientSound() { return ModSounds.BRUTE_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource source) { return ModSounds.BRUTE_HURT; }
    @Override
    public void tick() {
        super.tick();
        if (!this.getWorld().isClient && this.age % 120 == 0) {
            Box aura = this.getBoundingBox().expand(2.8);
            for (PlayerEntity player : this.getWorld().getEntitiesByClass(PlayerEntity.class, aura,
                    p -> p.isAlive() && !p.isSpectator())) {
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 35, 0, true, false, true));
            }
        }
    }

    @Override protected SoundEvent getDeathSound() { return ModSounds.BRUTE_DEATH; }
}
