package com.scarymonsterpack.item;

import com.scarymonsterpack.sound.ModSounds;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class WhisperLanternItem extends Item {
    public WhisperLanternItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 20 * 12, 0, false, false, true));
            world.playSound(null, user.getX(), user.getY(), user.getZ(), ModSounds.LANTERN_PULSE,
                    SoundCategory.PLAYERS, 0.85f, 1.0f);
            user.getItemCooldownManager().set(this, 20 * 28);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
