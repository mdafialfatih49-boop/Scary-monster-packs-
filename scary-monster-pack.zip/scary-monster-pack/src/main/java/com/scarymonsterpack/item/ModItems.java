package com.scarymonsterpack.item;

import com.scarymonsterpack.ScaryMonsterMod;
import com.scarymonsterpack.entity.ModEntities;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {
    public static final Item GLOOM_STALKER_SPAWN_EGG = register("gloom_stalker_spawn_egg",
            new SpawnEggItem(ModEntities.GLOOM_STALKER, 0x171522, 0xA33C5B, new Item.Settings()));
    public static final Item HOLLOW_WRAITH_SPAWN_EGG = register("hollow_wraith_spawn_egg",
            new SpawnEggItem(ModEntities.HOLLOW_WRAITH, 0x171C2B, 0x79B7C7, new Item.Settings()));
    public static final Item MIRE_BRUTE_SPAWN_EGG = register("mire_brute_spawn_egg",
            new SpawnEggItem(ModEntities.MIRE_BRUTE, 0x344A2B, 0x91A34A, new Item.Settings()));
    public static final Item BONE_CRAWLER_SPAWN_EGG = register("bone_crawler_spawn_egg",
            new SpawnEggItem(ModEntities.BONE_CRAWLER, 0xD9D0B8, 0x493D3A, new Item.Settings()));

    public static final Item WHISPER_LANTERN = register("whisper_lantern",
            new WhisperLanternItem(new Item.Settings().maxCount(1)));
    public static final Item ECHO_BELL = register("echo_bell",
            new EchoBellItem(new Item.Settings().maxCount(1)));
    public static final Item WARDING_CHARM = register("warding_charm",
            new WardingCharmItem(new Item.Settings().maxCount(1)));

    private ModItems() { }

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, new Identifier(ScaryMonsterMod.MOD_ID, name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> {
            entries.add(GLOOM_STALKER_SPAWN_EGG);
            entries.add(HOLLOW_WRAITH_SPAWN_EGG);
            entries.add(MIRE_BRUTE_SPAWN_EGG);
            entries.add(BONE_CRAWLER_SPAWN_EGG);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(WHISPER_LANTERN);
            entries.add(ECHO_BELL);
            entries.add(WARDING_CHARM);
        });
        ScaryMonsterMod.LOGGER.info("Registered monster eggs and spooky utility artifacts");
    }
}
