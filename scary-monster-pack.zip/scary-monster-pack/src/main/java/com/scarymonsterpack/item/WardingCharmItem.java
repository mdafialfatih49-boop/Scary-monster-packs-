package com.scarymonsterpack.item;

import com.scarymonsterpack.sound.ModSounds;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class WardingCharmItem extends Item {
    public WardingCharmItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 20 * 8, 0, false, false, true));
            user.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 20 * 8, 0, false, false, true));
            world.playSound(null, user.getX(), user.getY(), user.getZ(), ModSounds.WARDING_CHIME,
                    SoundCategory.PLAYERS, 0.9f, 1.15f);
            user.getItemCooldownManager().set(this, 20 * 32);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
