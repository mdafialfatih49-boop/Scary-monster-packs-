package com.scarymonsterpack.item;

import com.scarymonsterpack.sound.ModSounds;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class EchoBellItem extends Item {
    public EchoBellItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient) {
            world.playSound(null, user.getX(), user.getY(), user.getZ(), ModSounds.ECHO_CHIME,
                    SoundCategory.PLAYERS, 1.0f, 0.82f);
            for (HostileEntity monster : world.getEntitiesByClass(HostileEntity.class,
                    user.getBoundingBox().expand(14.0), entity -> entity.isAlive())) {
                monster.getLookControl().lookAt(user, 35.0f, 35.0f);
            }
            user.getItemCooldownManager().set(this, 20 * 18);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
