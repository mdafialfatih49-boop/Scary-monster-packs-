package com.scarymonsterpack.client.model;

import com.scarymonsterpack.entity.GloomStalkerEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class GloomStalkerModel extends SinglePartEntityModel<GloomStalkerEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;
    private final ModelPart cloak;

    public GloomStalkerModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
        this.cloak = root.getChild("cloak");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4, -8, -4, 8, 8, 8)
                .uv(32, 0).cuboid(-1, -10, -1, 2, 2, 2), ModelTransform.pivot(0, 0, 0));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 20).cuboid(-4, 0, -2, 8, 12, 4)
                .uv(24, 20).cuboid(-5, 1, -2.5f, 2, 7, 5), ModelTransform.pivot(0, 0, 0));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(32, 20).cuboid(-1.5f, -2, -1.5f, 3, 13, 3)
                .uv(44, 20).cuboid(-1.5f, 9, -2, 3, 4, 4), ModelTransform.pivot(5, 2, 0));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(32, 20).cuboid(-1.5f, -2, -1.5f, 3, 13, 3)
                .uv(44, 20).cuboid(-1.5f, 9, -2, 3, 4, 4), ModelTransform.pivot(-5, 2, 0));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(0, 32).cuboid(-1.5f, 0, -1.5f, 3, 12, 3), ModelTransform.pivot(2, 12, 0));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(14, 32).cuboid(-1.5f, 0, -1.5f, 3, 12, 3), ModelTransform.pivot(-2, 12, 0));
        root.addChild("cloak", ModelPartBuilder.create()
                .uv(24, 40).cuboid(-4.5f, 3, 2, 9, 9, 1)
                .uv(44, 40).cuboid(-5, 10, 2, 3, 5, 1)
                .uv(52, 40).cuboid(2, 9, 2, 3, 6, 1), ModelTransform.pivot(0, 0, 0));
        return TexturedModelData.of(data, 64, 64);
    }

    @Override
    public ModelPart getPart() {
        return root;
    }

    @Override
    public void setAngles(GloomStalkerEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;
        leftArm.pitch = MathHelper.cos(limbAngle * 0.6662f + MathHelper.PI) * 1.35f * limbDistance;
        rightArm.pitch = MathHelper.cos(limbAngle * 0.6662f) * 1.35f * limbDistance;
        leftLeg.pitch = MathHelper.cos(limbAngle * 0.6662f) * 1.15f * limbDistance;
        rightLeg.pitch = MathHelper.cos(limbAngle * 0.6662f + MathHelper.PI) * 1.15f * limbDistance;
        cloak.roll = MathHelper.sin(animationProgress * 0.08f) * 0.04f;
    }
}
