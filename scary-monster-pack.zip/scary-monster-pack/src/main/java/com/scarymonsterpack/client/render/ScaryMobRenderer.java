package com.scarymonsterpack.client.render;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.Identifier;

public class ScaryMobRenderer<T extends HostileEntity> extends MobEntityRenderer<T, EntityModel<T>> {
    private final Identifier texture;

    public ScaryMobRenderer(EntityRendererFactory.Context context, EntityModel<T> model,
                            float shadowRadius, Identifier texture) {
        super(context, model, shadowRadius);
        this.texture = texture;
    }

    @Override
    public Identifier getTexture(T entity) {
        return texture;
    }
}
