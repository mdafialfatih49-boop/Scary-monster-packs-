package com.scarymonsterpack.client.model;

import com.scarymonsterpack.entity.BoneCrawlerEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class BoneCrawlerModel extends SinglePartEntityModel<BoneCrawlerEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart[] legs = new ModelPart[8];

    public BoneCrawlerModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        String[] names = {"leg_fl", "leg_ml", "leg_bl", "leg_rl", "leg_fr", "leg_mr", "leg_br", "leg_rr"};
        for (int i = 0; i < names.length; i++) legs[i] = root.getChild(names[i]);
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("shell", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-5, -3, -6, 10, 6, 12)
                .uv(32, 0).cuboid(-3, -4, -4, 6, 2, 8), ModelTransform.pivot(0, 11, 0));
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 20).cuboid(-3, -2, -4, 6, 5, 5)
                .uv(24, 20).cuboid(-2, 1, -5, 4, 2, 2), ModelTransform.pivot(0, 11, -5));
        String[] names = {"leg_fl", "leg_ml", "leg_bl", "leg_rl", "leg_fr", "leg_mr", "leg_br", "leg_rr"};
        float[] xs = {4, 5, 5, 4, -4, -5, -5, -4};
        float[] zs = {-4, -1, 2, 5, -4, -1, 2, 5};
        for (int i = 0; i < names.length; i++) {
            boolean leftSide = i < 4;
            int uvX = 32 + (i % 3) * 8;
            root.addChild(names[i], ModelPartBuilder.create()
                    .uv(uvX, 28).cuboid(-1, 0, -1, 2, 9, 2)
                    .uv(uvX, 50).cuboid(-1.5f, 7, -1.5f, 3, 2, 3),
                    ModelTransform.of(xs[i], 11, zs[i], 0, 0, leftSide ? -0.72f : 0.72f));
        }
        root.addChild("tail", ModelPartBuilder.create()
                .uv(0, 46).cuboid(-1, -1, 0, 2, 2, 7), ModelTransform.pivot(0, 12, 5));
        return TexturedModelData.of(data, 64, 64);
    }

    @Override public ModelPart getPart() { return root; }

    @Override
    public void setAngles(BoneCrawlerEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;
        for (int i = 0; i < legs.length; i++) {
            float phase = (i % 2 == 0) ? 0.0f : MathHelper.PI;
            legs[i].pitch = MathHelper.cos(limbAngle * 0.9f + phase) * 0.22f * limbDistance;
            legs[i].roll = (i < 4 ? -0.72f : 0.72f) + MathHelper.sin(animationProgress * 0.08f + i) * 0.015f;
        }
    }
}
