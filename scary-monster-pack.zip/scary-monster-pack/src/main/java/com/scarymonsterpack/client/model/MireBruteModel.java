package com.scarymonsterpack.client.model;

import com.scarymonsterpack.entity.MireBruteEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class MireBruteModel extends SinglePartEntityModel<MireBruteEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public MireBruteModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-4, -8, -4, 8, 8, 8)
                .uv(32, 0).cuboid(-6, -6, -3, 2, 4, 3)
                .uv(42, 0).cuboid(4, -6, -3, 2, 4, 3), ModelTransform.pivot(0, 1, 0));
        root.addChild("body", ModelPartBuilder.create()
                .uv(0, 18).cuboid(-6, 0, -4, 12, 13, 8)
                .uv(18, 18).cuboid(-7, 3, -4.5f, 14, 5, 9), ModelTransform.pivot(0, 0, 0));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-2.5f, -2, -2.5f, 5, 11, 5)
                .uv(20, 40).cuboid(-3, 7, -3, 6, 5, 6), ModelTransform.pivot(8, 2, 0));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-2.5f, -2, -2.5f, 5, 11, 5)
                .uv(20, 40).cuboid(-3, 7, -3, 6, 5, 6), ModelTransform.pivot(-8, 2, 0));
        root.addChild("left_leg", ModelPartBuilder.create()
                .uv(44, 30).cuboid(-2, 0, -2, 4, 10, 4), ModelTransform.pivot(3, 13, 0));
        root.addChild("right_leg", ModelPartBuilder.create()
                .uv(44, 30).cuboid(-2, 0, -2, 4, 10, 4), ModelTransform.pivot(-3, 13, 0));
        root.addChild("back_spines", ModelPartBuilder.create()
                .uv(0, 48).cuboid(-4, 1, 3, 8, 5, 2)
                .uv(20, 48).cuboid(-2, -2, 4, 4, 4, 2), ModelTransform.pivot(0, 0, 0));
        return TexturedModelData.of(data, 64, 64);
    }

    @Override public ModelPart getPart() { return root; }

    @Override
    public void setAngles(MireBruteEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;
        leftArm.pitch = MathHelper.cos(limbAngle * 0.55f + MathHelper.PI) * 0.8f * limbDistance;
        rightArm.pitch = MathHelper.cos(limbAngle * 0.55f) * 0.8f * limbDistance;
        leftLeg.pitch = MathHelper.cos(limbAngle * 0.55f) * 0.7f * limbDistance;
        rightLeg.pitch = MathHelper.cos(limbAngle * 0.55f + MathHelper.PI) * 0.7f * limbDistance;
    }
}
