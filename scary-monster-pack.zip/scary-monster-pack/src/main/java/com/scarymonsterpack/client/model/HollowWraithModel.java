package com.scarymonsterpack.client.model;

import com.scarymonsterpack.entity.HollowWraithEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.util.math.MathHelper;

public class HollowWraithModel extends SinglePartEntityModel<HollowWraithEntity> {
    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart robe;
    private final ModelPart hemLeft;
    private final ModelPart hemRight;

    public HollowWraithModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.robe = root.getChild("robe");
        this.hemLeft = root.getChild("hem_left");
        this.hemRight = root.getChild("hem_right");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData data = new ModelData();
        ModelPartData root = data.getRoot();
        root.addChild("head", ModelPartBuilder.create()
                .uv(0, 0).cuboid(-3.5f, -8, -3.5f, 7, 8, 7)
                .uv(28, 0).cuboid(-4.5f, -7, -3.7f, 9, 3, 1), ModelTransform.pivot(0, 0, 0));
        root.addChild("robe", ModelPartBuilder.create()
                .uv(0, 18).cuboid(-5, 0, -3, 10, 14, 6)
                .uv(24, 18).cuboid(-6, 8, -3.5f, 12, 7, 7), ModelTransform.pivot(0, 0, 0));
        root.addChild("left_arm", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-1.5f, -1, -1.5f, 3, 12, 3)
                .uv(12, 40).cuboid(-2, 9, -2, 4, 4, 4), ModelTransform.pivot(6, 2, 0));
        root.addChild("right_arm", ModelPartBuilder.create()
                .uv(0, 30).cuboid(-1.5f, -1, -1.5f, 3, 12, 3)
                .uv(12, 40).cuboid(-2, 9, -2, 4, 4, 4), ModelTransform.pivot(-6, 2, 0));
        root.addChild("hem_left", ModelPartBuilder.create()
                .uv(20, 40).cuboid(-2, 0, -2, 4, 8, 4), ModelTransform.pivot(3, 12, 0));
        root.addChild("hem_right", ModelPartBuilder.create()
                .uv(36, 40).cuboid(-2, 0, -2, 4, 8, 4), ModelTransform.pivot(-3, 12, 0));
        root.addChild("hood_point", ModelPartBuilder.create()
                .uv(52, 0).cuboid(-1, -10, -1, 2, 4, 2), ModelTransform.pivot(0, 0, 0));
        return TexturedModelData.of(data, 64, 64);
    }

    @Override public ModelPart getPart() { return root; }

    @Override
    public void setAngles(HollowWraithEntity entity, float limbAngle, float limbDistance,
                          float animationProgress, float headYaw, float headPitch) {
        head.yaw = headYaw * 0.017453292f;
        head.pitch = headPitch * 0.017453292f;
        float sway = MathHelper.sin(animationProgress * 0.09f) * 0.12f;
        leftArm.roll = -0.18f + sway;
        rightArm.roll = 0.18f - sway;
        leftArm.pitch = MathHelper.sin(animationProgress * 0.07f) * 0.12f;
        rightArm.pitch = -leftArm.pitch;
        robe.pitch = MathHelper.sin(animationProgress * 0.06f) * 0.025f;
        hemLeft.roll = sway * 0.55f;
        hemRight.roll = -sway * 0.55f;
    }
}
