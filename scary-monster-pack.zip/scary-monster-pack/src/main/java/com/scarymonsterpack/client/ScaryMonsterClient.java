package com.scarymonsterpack.client;

import com.scarymonsterpack.ScaryMonsterMod;
import com.scarymonsterpack.client.model.BoneCrawlerModel;
import com.scarymonsterpack.client.model.GloomStalkerModel;
import com.scarymonsterpack.client.model.HollowWraithModel;
import com.scarymonsterpack.client.model.MireBruteModel;
import com.scarymonsterpack.client.render.ScaryMobRenderer;
import com.scarymonsterpack.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.util.Identifier;

public final class ScaryMonsterClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.GLOOM_STALKER, context ->
                new ScaryMobRenderer<>(context,
                        new GloomStalkerModel(GloomStalkerModel.getTexturedModelData().createModel()),
                        0.55f, texture("gloom_stalker")));
        EntityRendererRegistry.register(ModEntities.HOLLOW_WRAITH, context ->
                new ScaryMobRenderer<>(context,
                        new HollowWraithModel(HollowWraithModel.getTexturedModelData().createModel()),
                        0.45f, texture("hollow_wraith")));
        EntityRendererRegistry.register(ModEntities.MIRE_BRUTE, context ->
                new ScaryMobRenderer<>(context,
                        new MireBruteModel(MireBruteModel.getTexturedModelData().createModel()),
                        0.75f, texture("mire_brute")));
        EntityRendererRegistry.register(ModEntities.BONE_CRAWLER, context ->
                new ScaryMobRenderer<>(context,
                        new BoneCrawlerModel(BoneCrawlerModel.getTexturedModelData().createModel()),
                        0.35f, texture("bone_crawler")));
        ScaryMonsterMod.LOGGER.info("Registered custom monster renderers");
    }

    private static Identifier texture(String name) {
        return new Identifier(ScaryMonsterMod.MOD_ID, "textures/entity/" + name + ".png");
    }
}
