package com.scarymonsterpack;

import com.scarymonsterpack.entity.ModEntities;
import com.scarymonsterpack.item.ModItems;
import com.scarymonsterpack.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ScaryMonsterMod implements ModInitializer {
    public static final String MOD_ID = "scarymonster";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModSounds.register();
        ModEntities.register();
        ModItems.register();
        LOGGER.info("Scary Monster Pack loaded.");
    }
}
