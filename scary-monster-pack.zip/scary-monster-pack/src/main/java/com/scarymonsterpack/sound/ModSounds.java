package com.scarymonsterpack.sound;

import com.scarymonsterpack.ScaryMonsterMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
    public static final SoundEvent GLOOM_AMBIENT = register("gloom_ambient");
    public static final SoundEvent GLOOM_HURT = register("gloom_hurt");
    public static final SoundEvent GLOOM_DEATH = register("gloom_death");
    public static final SoundEvent WRAITH_AMBIENT = register("wraith_ambient");
    public static final SoundEvent WRAITH_HURT = register("wraith_hurt");
    public static final SoundEvent WRAITH_DEATH = register("wraith_death");
    public static final SoundEvent BRUTE_AMBIENT = register("brute_ambient");
    public static final SoundEvent BRUTE_HURT = register("brute_hurt");
    public static final SoundEvent BRUTE_DEATH = register("brute_death");
    public static final SoundEvent CRAWLER_AMBIENT = register("crawler_ambient");
    public static final SoundEvent CRAWLER_HURT = register("crawler_hurt");
    public static final SoundEvent CRAWLER_DEATH = register("crawler_death");
    public static final SoundEvent LANTERN_PULSE = register("lantern_pulse");
    public static final SoundEvent ECHO_CHIME = register("echo_chime");
    public static final SoundEvent WARDING_CHIME = register("warding_chime");

    private ModSounds() { }

    private static SoundEvent register(String name) {
        Identifier id = new Identifier(ScaryMonsterMod.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        ScaryMonsterMod.LOGGER.info("Registering Scary Monster Pack sounds");
    }
}
